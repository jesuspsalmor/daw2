<?php



DEFINE("BASE_PATH", __DIR__."/../");
DEFINE('CONFIG', BASE_PATH.'Config/');
DEFINE('CONTROLLERS', BASE_PATH.'Controllers/');
DEFINE('MODELS', BASE_PATH.'Models/');
DEFINE('VIEWS', BASE_PATH.'Views/');
DEFINE('DAO', BASE_PATH.'Models/DAOs/');