<?php
DEFINE('IP', 'localhost');
DEFINE('USER', 'root');
DEFINE('PASS', '');
DEFINE('DB', 'ligadeportiva');
?>